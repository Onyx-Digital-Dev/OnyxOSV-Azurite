{ config, pkgs, lib, ... }:

{
  imports = [
    ./hardware-configuration.nix

    # OSV Base Mods
    ./mods/base/osv-networking.nix
    ./mods/base/osv-core.nix

    # OSV Hardware Mods (choose ONE GPU mod)
    ./mods/hardware/gpu/nvidia-prime.nix
    # ./mods/hardware/gpu/nvidia.nix
    # ./mods/hardware/gpu/amd.nix
    # ./mods/hardware/gpu/intel.nix

    # OSV App Mods
    ./mods/apps/osv-gaming.nix
    ./mods/apps/osv-creator.nix
    # ./mods/apps/osv-developer.nix
    # ./mods/apps/osv-audiophile.nix
  ];

  # -----------------------------
  # OSV Base toggles
  # -----------------------------
  osv.base.core.enable = true;
  osv.base.core.secretService.seahorse = true;

  osv.base.networking.enable = true;
  osv.base.networking.hostName = "wraith";
  osv.base.networking.ssh.openFirewall = false;
  osv.base.networking.networkmanager.applet.enable = false;
  osv.base.networking.bluetooth.blueman.enable = false;

  # -----------------------------
  # OSV App toggles
  # -----------------------------
  osv.apps.gaming.enable = true;
  osv.apps.gaming.comms.discord.enable = true;
  osv.apps.gaming.comms.obs.enable = true;

  osv.apps.creator.enable = true;
  osv.apps.creator.graphics.enable = true;
  osv.apps.creator.video.enable = false;
  osv.apps.creator.audio.enable = false;

  # -----------------------------
  # Bootloader
  # -----------------------------
  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;

  # -----------------------------
  # Time & Locale
  # -----------------------------
  time.timeZone = "America/Los_Angeles";

  i18n.defaultLocale = "en_US.UTF-8";
  i18n.extraLocaleSettings = {
    LC_ADDRESS = "en_US.UTF-8";
    LC_IDENTIFICATION = "en_US.UTF-8";
    LC_MEASUREMENT = "en_US.UTF-8";
    LC_MONETARY = "en_US.UTF-8";
    LC_NAME = "en_US.UTF-8";
    LC_NUMERIC = "en_US.UTF-8";
    LC_PAPER = "en_US.UTF-8";
    LC_TELEPHONE = "en_US.UTF-8";
    LC_TIME = "en_US.UTF-8";
  };

  # -----------------------------
  # Printing
  # -----------------------------
  services.printing.enable = true;

  # -----------------------------
  # Audio baseline (audiophile mod will replace this)
  # -----------------------------
  security.polkit.enable = true;
  services.pulseaudio.enable = false;
  security.rtkit.enable = true;

  services.pipewire = {
    enable = true;
    alsa.enable = true;
    alsa.support32Bit = true;
    pulse.enable = true;
  };

  # -----------------------------
  # User
  # -----------------------------
  users.users.oskodiak = {
    isNormalUser = true;
    description = "Kodiak";
    extraGroups = [ "networkmanager" "wheel" ];
  };

  # -----------------------------
  # Base apps (minimal)
  # -----------------------------
  programs.firefox.enable = true;

  # -----------------------------
  # Nix
  # -----------------------------
  nix.settings.experimental-features = [ "nix-command" "flakes" ];

  # -----------------------------
  # OSV Environment (DMS “to the letter”)
  # -----------------------------

  # Wayland-only stack.
  services.xserver.enable = false;

  # Install compositor via NixOS so it appears in the greeter session list.
  # (DankGreeter docs explicitly warn compositors must be installed via NixOS config)
  programs.niri.enable = true; # :contentReference[oaicite:2]{index=2}

  # Ensure the Niri session .desktop is present for display managers.
  services.displayManager.sessionPackages = [ pkgs.niri ];

  # DankMaterialShell (system-level)
  programs.dankMaterialShell = {
    enable = true;
    systemd = {
      enable = true;
      restartIfChanged = true;
    };
  }; # :contentReference[oaicite:3]{index=3}

  # DankGreeter (flake module)
  programs.dankMaterialShell.greeter = {
    enable = true;

    compositor = {
      name = "niri";
      # Leave customConfig empty unless you *need* greeter-specific compositor config.
      # customConfig = "";
    };

    # Theme/settings sync (matches DankGreeter flake docs)
    configHome = "/home/oskodiak";
    configFiles = [
      "/home/oskodiak/.config/DankMaterialShell/settings.json"
    ];

    # Optional but useful during stabilization
    logs = {
      save = true;
      path = "/tmp/dms-greeter.log";
    };
  }; # :contentReference[oaicite:4]{index=4}

  # Portals baseline for Wayland apps.
  xdg.portal.enable = true;
  xdg.portal.extraPortals = with pkgs; [
    xdg-desktop-portal-gtk
    xdg-desktop-portal-gnome
  ];

  # X11 compatibility (Steam/X11 apps): keep this.
  environment.systemPackages = with pkgs; [
    xwayland-satellite
  ];

  environment.sessionVariables = {
    XDG_CURRENT_DESKTOP = "niri";
    XDG_SESSION_DESKTOP = "niri";
    NIXOS_OZONE_WL = "1";
  };

  # (Optional) If you want to avoid the tty2 “dual session / weird flow” during demos:
  # systemd.services."getty@tty2".enable = false;
  # systemd.services."autovt@tty2".enable = false;

  # -----------------------------
  # State version
  # -----------------------------
  system.stateVersion = "25.11";
}
