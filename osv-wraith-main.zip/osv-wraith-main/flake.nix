{
  description = "wraith - Niri + DankMaterialShell + DankGreeter (flake modules)";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

    dms = {
      url = "github:AvengeMedia/DankMaterialShell/stable";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs = { self, nixpkgs, dms, ... }:
  let
    system = "x86_64-linux";
  in {
    nixosConfigurations.wraith = nixpkgs.lib.nixosSystem {
      inherit system;

      modules = [
        ./configuration.nix

        # DankMaterialShell NixOS module
        dms.nixosModules.dankMaterialShell

        # DankGreeter NixOS module (the “official” greeter module in the DMS flake docs)
        dms.nixosModules.greeter
      ];
    };
  };
}
