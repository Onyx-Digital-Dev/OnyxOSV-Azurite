{ config, pkgs, lib, ... }:

let
  cfg = config.osv.hardware.gpu.nvidiaPrime;

  wrapperName = config.osv.hardware.gpu.wrapperName;

  # Purpose: OSV GPU wrapper for NVIDIA PRIME offload.
  # Notes: Uses environment variables recognized by the NVIDIA driver stack. :contentReference[oaicite:2]{index=2}
  osvGpuRunPrime = pkgs.writeShellScriptBin wrapperName ''
    set -euo pipefail

    export __NV_PRIME_RENDER_OFFLOAD=1
    export __NV_PRIME_RENDER_OFFLOAD_PROVIDER="${cfg.nvidiaProvider}"
    export __GLX_VENDOR_LIBRARY_NAME=nvidia
    export __VK_LAYER_NV_optimus=NVIDIA_only

    exec "$@"
  '';
in
{
  imports = [
    ./osv-gpu.nix
  ];

  options.osv.hardware.gpu.nvidiaPrime = {
    enable = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Enable NVIDIA PRIME offload configuration (Intel iGPU + NVIDIA dGPU).";
    };

    intelBusId = lib.mkOption {
      type = lib.types.str;
      default = "PCI:0:2:0";
      description = "PCI bus ID for the Intel iGPU (PRIME).";
    };

    nvidiaBusId = lib.mkOption {
      type = lib.types.str;
      default = "PCI:1:0:0";
      description = "PCI bus ID for the NVIDIA dGPU (PRIME).";
    };

    nvidiaProvider = lib.mkOption {
      type = lib.types.str;
      default = "NVIDIA-G0";
      description = "GL/Vulkan provider name used for PRIME offload on most systems.";
    };

    enableNvidiaSettings = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Install and enable NVIDIA Settings.";
    };

    driverPackage = lib.mkOption {
      type = lib.types.package;
      default = config.boot.kernelPackages.nvidiaPackages.stable;
      description = "NVIDIA driver package to use.";
    };
  };

  config = lib.mkIf (config.osv.hardware.gpu.enable && cfg.enable) {
    nixpkgs.config.allowUnfree = lib.mkDefault true;

    services.xserver.videoDrivers = [ "nvidia" ];

    # Purpose: PRIME offload configuration.
    # Notes: OSV targets offload mode for laptops; sync mode is a separate profile decision.
    hardware.nvidia = {
      modesetting.enable = true;

      open = false;
      nvidiaSettings = cfg.enableNvidiaSettings;
      package = cfg.driverPackage;

      # Purpose: Conservative power defaults.
      # Notes: Keep suspend/resume risk low; tune later in a dedicated power mod if needed.
      powerManagement.enable = lib.mkDefault false;
      powerManagement.finegrained = lib.mkDefault false;

      prime = {
        offload = {
          enable = true;

          # Purpose: Provide NixOS-maintained offload helper for debugging and parity checks.
          # Notes: This installs `nvidia-offload` by default; OSV keeps `osv-gpu-run` as the interface. :contentReference[oaicite:3]{index=3}
          enableOffloadCmd = true;
          # offloadCmdMainProgram = "nvidia-offload"; # default; keep stable and non-conflicting :contentReference[oaicite:4]{index=4}
        };

        intelBusId = cfg.intelBusId;
        nvidiaBusId = cfg.nvidiaBusId;
      };
    };

    boot.kernelParams = [ "nvidia-drm.modeset=1" ];

    # Purpose: Provide PRIME-aware OSV wrapper.
    # Notes: osv-gpu.nix intentionally does not install the no-op wrapper when PRIME is enabled.
    environment.systemPackages = [ osvGpuRunPrime ];
  };
}
