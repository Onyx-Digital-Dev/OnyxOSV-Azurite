{ config, pkgs, lib, ... }:

let
  cfg = config.osv.hardware.gpu;

  # Purpose: Provide a stable OSV-owned GPU wrapper command.
  # Notes: Vendor mods may override this wrapper with specialized behavior.
  osvGpuRun = pkgs.writeShellScriptBin cfg.wrapperName ''
    set -euo pipefail
    exec "$@"
  '';

  # Purpose: Avoid conflicting wrappers when PRIME provides the real implementation.
  # Notes: This keeps wrapper behavior deterministic across the system.
  primeEnabled =
    (config.osv.hardware.gpu.nvidiaPrime.enable or false);
in
{
  options.osv.hardware.gpu = {
    enable = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Enable OSV GPU baseline (stable wrapper + graphics stack toggles).";
    };

    wrapperName = lib.mkOption {
      type = lib.types.str;
      default = "osv-gpu-run";
      description = "Name of the OSV GPU wrapper command exposed to app mods.";
    };

    enable32Bit = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Enable 32-bit graphics support (required by many Proton/legacy titles).";
    };

    enableGraphicsStack = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Enable the system graphics stack via hardware.graphics.*.";
    };
  };

  config = lib.mkIf cfg.enable {
    # Purpose: Provide a correct baseline graphics stack.
    # Notes: Vendor mods may add drivers; this stays vendor-agnostic.
    hardware.graphics = lib.mkIf cfg.enableGraphicsStack {
      enable = true;
      enable32Bit = cfg.enable32Bit;
    };

    # Purpose: Ensure app mods have a stable wrapper regardless of vendor.
    # Notes: If PRIME is enabled, PRIME owns the wrapper implementation.
    environment.systemPackages = lib.mkIf (!primeEnabled) [ osvGpuRun ];
  };
}
