{ config, pkgs, lib, ... }:

{
  imports = [
    ./osv-gpu.nix
  ];

  # Purpose: AMD graphics baseline for OSV.
  # Notes: On modern NixOS, AMD typically works without explicit driver selection.
  # Notes: If X11 is enabled, "modesetting" remains the conservative default driver path.
  #        On Wayland compositors, this setting is generally not impactful. :contentReference[oaicite:5]{index=5}

  config = lib.mkIf config.osv.hardware.gpu.enable {
    services.xserver.videoDrivers = lib.mkDefault [ "modesetting" ];
  };
}
