{ config, pkgs, lib, ... }:

{
  imports = [
    ./osv-gpu.nix
  ];

  # Purpose: Intel graphics baseline for OSV.
  # Notes: Mesa handles the bulk of the stack; keep policy conservative.
  # Notes: If X11 is enabled, "modesetting" is the correct baseline; on Wayland it is typically irrelevant.

  config = lib.mkIf config.osv.hardware.gpu.enable {
    services.xserver.videoDrivers = lib.mkDefault [ "modesetting" ];
  };
}
