{ config, pkgs, lib, ... }:

{
  imports = [
    ./osv-gpu.nix
  ];

  # Purpose: NVIDIA baseline where NVIDIA is the primary renderer (non-PRIME).
  # Notes: This mod does not configure PRIME offload; use nvidia-prime.nix for hybrid laptops.

  config = lib.mkIf config.osv.hardware.gpu.enable {
    # Purpose: NVIDIA requires unfree packages.
    # Notes: mkDefault allows a core/base mod to control this globally.
    nixpkgs.config.allowUnfree = lib.mkDefault true;

    services.xserver.videoDrivers = [ "nvidia" ];

    hardware.nvidia = {
      modesetting.enable = true;

      # Purpose: Default to proprietary stack for stability.
      # Notes: The open kernel modules can regress acceleration on some setups. :contentReference[oaicite:6]{index=6}
      open = false;

      nvidiaSettings = true;

      # Purpose: OSV favors reliability over experimental branches.
      package = config.boot.kernelPackages.nvidiaPackages.stable;

      # Purpose: Keep power management conservative by default.
      # Notes: There have been suspend/resume issues associated with powerManagement in recent unstable. :contentReference[oaicite:7]{index=7}
      powerManagement.enable = lib.mkDefault false;
      powerManagement.finegrained = lib.mkDefault false;

      # Purpose: Do not enable nvidiaPersistenced by default.
      # Notes: There is a reported build failure on 25.11 when enabling it. :contentReference[oaicite:8]{index=8}
      # nvidiaPersistenced = false;
    };

    boot.kernelParams = [ "nvidia-drm.modeset=1" ];
  };
}
