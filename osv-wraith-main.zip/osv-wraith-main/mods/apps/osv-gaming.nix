{ config, pkgs, lib, ... }:

let
  cfg = config.osv.apps.gaming;

  # Purpose: Resolve an optional wrapper command safely.
  # Notes: If the wrapper is not found, execution continues without it.
  wrapIfPresent = name: ''
    if command -v "${name}" >/dev/null 2>&1; then
      set -- "${name}" "$@"
    fi
  '';

  # Purpose: OSV-standard runtime wrapper for launching games.
  # Notes: Intended for Steam launch options and general use (no user-home writes).
  #
  # Steam per-game fallback (rare; usually unnecessary):
  #   Steam -> Game -> Properties -> Launch Options:
  #     osv-game %command%
  #
  # Heroic per-game recommendation (manual, explicit, predictable):
  #   Heroic -> Game Settings -> Advanced -> Launch Options:
  #     osv-game
  osvGame = pkgs.writeShellScriptBin "osv-game" ''
    set -euo pipefail

    # Purpose: Steam/Proton (pressure-vessel) can enter a bwrap sandbox that does not mount host paths.
    # Notes: Avoid launching from directories like /etc/nixos to prevent "bwrap: Can't chdir" failures.
    cd "$HOME" 2>/dev/null || cd /tmp

    ${lib.optionalString cfg.enableGameMode (wrapIfPresent "gamemoderun")}
    ${lib.optionalString cfg.enableMangoHud (wrapIfPresent "mangohud")}
    ${lib.optionalString (cfg.gpuWrapper != "") (wrapIfPresent cfg.gpuWrapper)}

    exec "$@"
  '';

  # Purpose: Launch Steam using OSV runtime policy.
  # Notes:
  # - This is the preferred OSV launch path for Steam.
  # - Steam and all child game processes inherit OSV policy (GPU wrapper, MangoHud, GameMode).
  osvSteam = pkgs.writeShellScriptBin "osv-steam" ''
    set -euo pipefail

    # Purpose: Steam frequently enters a bwrap sandbox (pressure-vessel) that does not mount arbitrary host paths.
    # Notes: Ensure a safe working directory before exec to avoid "bwrap: Can't chdir" failures.
    cd "$HOME" 2>/dev/null || cd /tmp

    ${lib.optionalString cfg.enableGameMode (wrapIfPresent "gamemoderun")}
    ${lib.optionalString cfg.enableMangoHud (wrapIfPresent "mangohud")}
    ${lib.optionalString (cfg.gpuWrapper != "") (wrapIfPresent cfg.gpuWrapper)}

    exec ${pkgs.steam}/bin/steam "$@"
  '';

  # Purpose: Guarantee launcher-driven Steam starts inherit OSV policy.
  # Notes:
  # - Many launchers and .desktop files invoke `steam` by name.
  # - XDG desktop entry precedence can favor user entries; PATH-level override is deterministic.
  # - This does not modify user home. It simply makes `steam` == `osv-steam`.
  osvSteamCmd = pkgs.writeShellScriptBin "steam" ''
    set -euo pipefail

    # Purpose: Prevent bwrap chdir failures when `steam` is launched from /etc/nixos (or other non-mounted paths).
    cd "$HOME" 2>/dev/null || cd /tmp

    exec osv-steam "$@"
  '';
in
{
  options.osv.apps.gaming = {
    enable = lib.mkEnableOption "OSV gaming stack (launchers and runtime helpers).";

    gpuWrapper = lib.mkOption {
      type = lib.types.str;
      default = "osv-gpu-run";
      example = "osv-gpu-run";
      description = "GPU wrapper command provided by OSV hardware mods. Set to \"\" to disable.";
    };

    enableGameMode = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Enable GameMode and apply it in OSV wrappers when available.";
    };

    enableMangoHud = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Install MangoHud and apply it in OSV wrappers when available.";
    };

    steam = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Enable Steam.";
      };

      remotePlayOpenFirewall = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Open firewall for Steam Remote Play.";
      };

      dedicatedServerOpenFirewall = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Open firewall for Steam dedicated server hosting.";
      };

      # Purpose: Launcher-friendly Steam entry for OSV policy.
      # Notes: This writes /etc/xdg/applications/steam.desktop (system-wide override).
      useOSVDesktopEntry = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Override Steam desktop entry to Exec=osv-steam so launchers use OSV policy when system entries are preferred.";
      };

      # Purpose: Deterministic OSV policy for Steam regardless of desktop entry precedence.
      # Notes: Recommended default for DMS/Niri launcher workflows.
      forceOSVSteamCommand = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install an OSV `steam` wrapper that execs `osv-steam` so Steam launched from any menu/launcher inherits OSV policy.";
      };
    };

    heroic.enable = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Enable Heroic (Epic/GOG/Amazon).";
    };

    tools = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install common gaming tools.";
      };

      gamescope.enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install gamescope.";
      };

      protonup.enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install protonup-qt.";
      };

      winetricks.enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install winetricks (useful for non-Steam titles).";
      };
    };

    comms = {
      # Purpose: Temporary bridge until Exom is ready.
      discord.enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install Discord (temporary default until Exom replaces it).";
      };

      # Purpose: Capture and streaming utility without expanding into a separate pack.
      obs.enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install OBS Studio.";
      };
    };

    extraPackages = lib.mkOption {
      type = lib.types.listOf lib.types.package;
      default = [];
      description = "Additional packages to install with the gaming stack.";
    };
  };

  config = lib.mkIf cfg.enable (lib.mkMerge [

    # Purpose: Steam support.
    (lib.mkIf cfg.steam.enable {
      programs.steam = {
        enable = true;
        remotePlay.openFirewall = cfg.steam.remotePlayOpenFirewall;
        dedicatedServer.openFirewall = cfg.steam.dedicatedServerOpenFirewall;
      };

      # Purpose: Steam device udev rules (controllers and Steam hardware).
      hardware.steam-hardware.enable = true;

      # Purpose: Wayland compatibility hint for Chromium-based render paths.
      environment.sessionVariables.NIXOS_OZONE_WL = "1";
    })

    # Purpose: Ensure launcher-driven Steam always uses OSV policy.
    # Notes: DMS/Niri launchers typically use .desktop entries, but user-level entries can override system ones.
    # This system entry is still useful, but not relied upon exclusively.
    (lib.mkIf (cfg.steam.enable && cfg.steam.useOSVDesktopEntry) {
      environment.etc."xdg/applications/steam.desktop".text = ''
        [Desktop Entry]
        Type=Application
        Version=1.0
        Name=Steam
        Comment=Steam (launched via OSV policy wrapper)
        Exec=osv-steam %U
        TryExec=osv-steam
        Icon=steam
        Terminal=false
        Categories=Game;Network;
        StartupNotify=true
        StartupWMClass=steam
      '';
    })

    # Purpose: Provide deterministic PATH-level Steam command override.
    # Notes: This ensures `steam` launched from any launcher/menu inherits OSV policy.
    (lib.mkIf (cfg.steam.enable && cfg.steam.forceOSVSteamCommand) {
      environment.systemPackages = [ osvSteamCmd ];
    })

    # Purpose: Heroic launcher.
    # Notes: OSV does not auto-wrap Heroic game launches.
    (lib.mkIf cfg.heroic.enable {
      environment.systemPackages = [ pkgs.heroic ];
    })

    # Purpose: GameMode service (system-level).
    (lib.mkIf cfg.enableGameMode {
      programs.gamemode.enable = true;
    })

    # Purpose: Packages and OSV wrappers.
    {
      environment.systemPackages =
        (with pkgs; [
          osvGame
          osvSteam

          steam-run
          vulkan-tools
        ])
        ++ lib.optionals cfg.enableMangoHud [ pkgs.mangohud ]
        ++ lib.optionals (cfg.tools.enable && cfg.tools.gamescope.enable) [ pkgs.gamescope ]
        ++ lib.optionals (cfg.tools.enable && cfg.tools.protonup.enable) [ pkgs.protonup-qt ]
        ++ lib.optionals (cfg.tools.enable && cfg.tools.winetricks.enable) [ pkgs.winetricks ]
        ++ lib.optionals cfg.comms.discord.enable [ pkgs.discord ]
        ++ lib.optionals cfg.comms.obs.enable [ pkgs.obs-studio ]
        ++ cfg.extraPackages;
    }

    # Purpose: Unfree packages (Steam/Discord, and often NVIDIA ecosystems).
    # Notes: Prefer placing this in a core/base mod later; mkDefault prevents surprises.
    (lib.mkIf (cfg.steam.enable || cfg.comms.discord.enable) {
      nixpkgs.config.allowUnfree = lib.mkDefault true;
    })
  ]);
}
