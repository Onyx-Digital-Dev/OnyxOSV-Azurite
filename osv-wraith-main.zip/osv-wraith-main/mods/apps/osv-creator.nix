{ config, pkgs, lib, ... }:

let
  cfg = config.osv.apps.creator;
in
{
  options.osv.apps.creator = {
    enable = lib.mkEnableOption "OSV Creator stack (creative production tools).";

    graphics = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Graphic design essentials (Krita, Inkscape, GIMP, Blender).";
      };

      extraPackages = lib.mkOption {
        type = lib.types.listOf lib.types.package;
        default = [];
        description = "Additional graphics packages to install.";
      };
    };

    video = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Video production essentials (open-source, minimal babysitting).";
      };

      extraPackages = lib.mkOption {
        type = lib.types.listOf lib.types.package;
        default = [];
        description = "Additional video packages to install.";
      };
    };

    audio = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Audio creation tools only (device/settings live in hardware/audiophile.nix).";
      };

      extraPackages = lib.mkOption {
        type = lib.types.listOf lib.types.package;
        default = [];
        description = "Additional audio packages to install.";
      };
    };
  };

  config = lib.mkIf cfg.enable {
    environment.systemPackages =
      # Graphics
      (lib.optionals cfg.graphics.enable (with pkgs; [
        krita
        inkscape
        gimp
        blender
      ]))
      ++ (lib.optionals cfg.graphics.enable cfg.graphics.extraPackages)

      # Video (3 tools + backbone utilities)
      ++ (lib.optionals cfg.video.enable (with pkgs; [
        kdenlive
        shotcut
        avidemux

        ffmpeg
        mediainfo
      ]))
      ++ (lib.optionals cfg.video.enable cfg.video.extraPackages)


      # Audio (tools only; no system tuning here)
      ++ (lib.optionals cfg.audio.enable (with pkgs; [
        ardour
        audacity
        lmms

        # Plugins (LV2/LADSPA)
        lsp-plugins
        calf

        # Optional utilities (doesn't force JACK on)
        qjackctl
        helm
      ]))
      ++ (lib.optionals cfg.audio.enable cfg.audio.extraPackages);
  };
}
