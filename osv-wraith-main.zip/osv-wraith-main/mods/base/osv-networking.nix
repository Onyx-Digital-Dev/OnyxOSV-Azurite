{ config, pkgs, lib, ... }:

let
  cfg = config.osv.base.networking;

  # Coerce user-friendly wifiPowersave to what NixOS expects:
  # NixOS option type: null or boolean
  # We accept: null | bool | int (0/1/2/3) for sanity and backwards compatibility.
  nmWifiPowersaveBool =
    let v = cfg.networkmanager.wifiPowersave;
    in if v == null then null else
       if builtins.isBool v then v else
       if builtins.isInt v then
         # 0/2 => off, 1/3 => on
         if (v == 1 || v == 3) then true else false
       else
         false;
in
{
  options.osv.base.networking = {
    enable = lib.mkEnableOption "OSV networking baseline (connectivity stack and secure defaults).";

    hostName = lib.mkOption {
      type = lib.types.nullOr lib.types.str;
      default = null;
      description = "Optional hostname. If null, this mod will not set networking.hostName.";
    };

    networkmanager = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Enable NetworkManager (recommended for OSV + laptops/workstations).";
      };

      # OSV policy: nm-applet is NOT part of the default UX (Alopex will replace it).
      applet.enable = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Install nm-applet (NetworkManager tray applet). Off by default on OSV.";
      };

      wifiPowersave = lib.mkOption {
        type = lib.types.nullOr (lib.types.either lib.types.bool lib.types.int);
        default = false;
        description = ''
          Wi-Fi powersave policy.
          - false: disable powersave (preferred for stability/latency)
          - true: enable powersave
          - null: leave unspecified (let NixOS/NM decide)
          - also accepts ints: 0/2 => off, 1/3 => on (coerced)
        '';
      };

      dns = lib.mkOption {
        type = lib.types.enum [ "systemd-resolved" "none" ];
        default = "systemd-resolved";
        description = "DNS integration strategy used with NetworkManager.";
      };
    };

    dns = {
      enableResolved = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Enable systemd-resolved (recommended).";
      };

      fallbackServers = lib.mkOption {
        type = lib.types.listOf lib.types.str;
        default = [ "1.1.1.1" "1.0.0.1" "8.8.8.8" "8.8.4.4" ];
        description = "Fallback DNS servers used by systemd-resolved when upstream is unavailable.";
      };

      dnssec = lib.mkOption {
        type = lib.types.enum [ "no" "allow-downgrade" "yes" ];
        default = "allow-downgrade";
        description = "DNSSEC mode for systemd-resolved.";
      };
    };

    firewall = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Enable the NixOS firewall (nftables backend).";
      };

      allowPing = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Allow ICMP echo requests. Off by default for a quieter footprint.";
      };

      allowedTCPPorts = lib.mkOption {
        type = lib.types.listOf lib.types.port;
        default = [ ];
        description = "Extra allowed TCP ports.";
      };

      allowedUDPPorts = lib.mkOption {
        type = lib.types.listOf lib.types.port;
        default = [ ];
        description = "Extra allowed UDP ports.";
      };
    };

    ssh = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Enable OpenSSH daemon.";
      };

      passwordAuthentication = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Allow SSH password authentication. Off by default (prefer keys).";
      };

      permitRootLogin = lib.mkOption {
        type = lib.types.enum [ "no" "prohibit-password" "yes" ];
        default = "no";
        description = "Root login policy for SSH.";
      };

      openFirewall = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Open firewall for SSH (port 22). Off by default; enable when needed.";
      };
    };

    tailscale = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Enable Tailscale.";
      };

      openFirewall = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Let Tailscale manage required firewall rules.";
      };

      useRoutingFeatures = lib.mkOption {
        type = lib.types.enum [ "none" "client" "server" "both" ];
        default = "none";
        description = "Tailscale routing features (advertise routes / accept routes).";
      };
    };

    wireguard = {
      enableTools = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install WireGuard tools (wg, wg-quick).";
      };
    };

    openvpn = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install OpenVPN + NetworkManager OpenVPN plugin.";
      };
    };

    bluetooth = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Enable Bluetooth stack (BlueZ).";
      };

      # OSV policy: DMS owns bluetooth UX; blueman adds tray applet.
      blueman.enable = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Enable Blueman (adds tray applet). Off by default on OSV because DMS owns Bluetooth UX.";
      };

      tools = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Install Bluetooth tools (bluetoothctl and friends).";
      };
    };

    packages = {
      extra = lib.mkOption {
        type = lib.types.listOf lib.types.package;
        default = [ ];
        description = "Additional networking packages for this mod.";
      };
    };
  };

  config = lib.mkIf cfg.enable (lib.mkMerge [

    (lib.mkIf (cfg.hostName != null) {
      networking.hostName = cfg.hostName;
    })

    {
      networking.firewall = {
        enable = cfg.firewall.enable;
        allowPing = cfg.firewall.allowPing;
        allowedTCPPorts = cfg.firewall.allowedTCPPorts;
        allowedUDPPorts = cfg.firewall.allowedUDPPorts;
      };
    }

    (lib.mkIf cfg.networkmanager.enable {
      networking.networkmanager.enable = true;

      networking.networkmanager.wifi.powersave = nmWifiPowersaveBool;

      networking.networkmanager.dns =
        if cfg.networkmanager.dns == "none" then "none" else "systemd-resolved";
    })

    (lib.mkIf cfg.dns.enableResolved {
      services.resolved = {
        enable = true;
        dnssec = cfg.dns.dnssec;
        fallbackDns = cfg.dns.fallbackServers;
      };
    })

    (lib.mkIf cfg.ssh.enable {
      services.openssh = {
        enable = true;
        settings = {
          PasswordAuthentication = cfg.ssh.passwordAuthentication;
          PermitRootLogin = cfg.ssh.permitRootLogin;
        };
      };
    })

    (lib.mkIf cfg.ssh.openFirewall {
      networking.firewall.allowedTCPPorts = lib.mkAfter [ 22 ];
    })

    (lib.mkIf cfg.tailscale.enable {
      services.tailscale = {
        enable = true;
        openFirewall = cfg.tailscale.openFirewall;
        useRoutingFeatures = cfg.tailscale.useRoutingFeatures;
      };
    })

    (lib.mkIf cfg.bluetooth.enable {
      hardware.bluetooth.enable = true;
      services.blueman.enable = cfg.bluetooth.blueman.enable;
    })

    {
      environment.systemPackages =
        (lib.optionals (cfg.networkmanager.enable && cfg.networkmanager.applet.enable) (with pkgs; [
          networkmanagerapplet
        ]))
        ++ (lib.optionals cfg.wireguard.enableTools (with pkgs; [
          wireguard-tools
        ]))
        ++ (lib.optionals cfg.openvpn.enable (with pkgs; [
          openvpn
          networkmanager-openvpn
        ]))
        ++ (lib.optionals (cfg.bluetooth.enable && cfg.bluetooth.tools) (with pkgs; [
          bluez
          bluez-tools
        ]))
        ++ cfg.packages.extra;
    }
  ]);
}
