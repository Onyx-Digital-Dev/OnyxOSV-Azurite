{ config, pkgs, lib, ... }:

let
  cfg = config.osv.base.core;
in
{
  options.osv.base.core = {
    enable = lib.mkEnableOption "OSV core baseline (survival kit + safe defaults).";

    allowUnfree = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Allow unfree packages system-wide (kept in core so installs don’t surprise users).";
    };

    # Secret Service provider for apps that expect org.freedesktop.secrets
    secretService = {
      enable = lib.mkOption {
        type = lib.types.bool;
        default = true;
        description = "Enable a Secret Service provider (GNOME Keyring). Helps apps that store tokens/passwords.";
      };

      seahorse = lib.mkOption {
        type = lib.types.bool;
        default = false;
        description = "Install Seahorse (GUI for keyrings). Off by default.";
      };
    };

    packages = {
      extra = lib.mkOption {
        type = lib.types.listOf lib.types.package;
        default = [ ];
        description = "Extra 'core' packages for this machine.";
      };
    };
  };

  config = lib.mkIf cfg.enable (lib.mkMerge [
    # Unfree policy lives here (core), not in environment or app stacks.
    {
      nixpkgs.config.allowUnfree = lib.mkDefault cfg.allowUnfree;
    }

    # Core plumbing that lots of non-GNOME desktops still need.
    # (env will also set these, but mkDefault prevents fights)
    {
      services.dbus.enable = lib.mkDefault true;
      programs.dconf.enable = lib.mkDefault true;
    }

    # Secret Service provider (GNOME Keyring)
    (lib.mkIf cfg.secretService.enable {
      services.gnome.gnome-keyring.enable = true;
      programs.seahorse.enable = lib.mkDefault cfg.secretService.seahorse;
    })

    # Core “oh shit” toolbelt (small, high-signal, no desktop UX)
    {
      environment.systemPackages = with pkgs; [
        # Editors (pick your poison — both is fine)
        vim
        helix
        kitty

        # Fetch / VCS
        curl
        wget
        git

        # Inspect / debug
        ripgrep
        fd
        lsd
        jq
        file
        tree
        unzip
        zip
        p7zip

        # System triage
        htop
        btop
        ncdu
        lsof
        strace
        pciutils
        usbutils
        dmidecode

        # Networking triage (NM tools are in osv-networking)
        iproute2
        iputils
        dnsutils
        traceroute
        mtr
        nmap

        # Remote / session helpers
        tmux
        rsync
        claude-code

        # Crypto / trust
        openssl
        gnupg
      ] ++ cfg.packages.extra;
    }
  ]);
}
